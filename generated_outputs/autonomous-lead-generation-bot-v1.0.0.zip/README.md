# Autonomous Lead Generation Bot

An automated lead scoring pipeline built with Python and Gemini API.

## Features
- Evaluates ICP (Ideal Customer Profile) metrics.
- Computes Tier 1 / Tier 2 qualification scores.
- Ready to hook into CRM webhooks or Apollo.io.
